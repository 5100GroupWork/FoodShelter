/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.Role;

import javax.swing.JPanel;
import model.Account.UserAccount;
import model.Enterprise.BasicEnterprise;
import model.FoodItem.FoodItem;
import model.FoodShelterSystem.FoodShelterSystem;
import model.NetWork.NetWork;
import model.Organization.BasicOrganization;
import model.WorkQueue.WorkQueue;
import model.WorkQueue.WorkRequestFoodItem;
import ui.FreshCheckWorkArea.NewFoodCheckPanel;
import ui.HomelessWorkArea.HomelessWorkPanel;

/**
 *
 * @author 59386
 */
public class FreshChecker extends BasicRole{

    // freshChecker check the foodItem
    public WorkQueue getAllfoodItem(NetWork netWork){
        return netWork.getCheckList();
    }
    
    // check the foodItem
    public void checkFoodItem(WorkRequestFoodItem workRequestFoodItem,String status){
        FoodItem foodItem = workRequestFoodItem.getFoodItem();
        foodItem.setFoodStatus(status);
    }
    
    
    @Override
    public JPanel createWorkArea(JPanel workArea, UserAccount account, BasicOrganization organization, BasicEnterprise enterprise, NetWork netWork,FoodShelterSystem system) {
        
        return new NewFoodCheckPanel(workArea,account,organization,enterprise,netWork);
    }

}
