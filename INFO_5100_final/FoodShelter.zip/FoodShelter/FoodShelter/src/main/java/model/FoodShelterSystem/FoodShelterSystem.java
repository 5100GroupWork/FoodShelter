/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.FoodShelterSystem;

import java.util.ArrayList;
import model.Account.UserAccount;
import model.NetWork.NetWork;
import model.Organization.BasicOrganization;
import model.Role.BasicRole;
import model.Role.SysAdmin;
//import model.Role.SystemAdmin;

/**
 *
 * @author 59386
 */
public class FoodShelterSystem extends BasicOrganization{
    private static FoodShelterSystem business;
    private ArrayList<NetWork> networkList;

    
    private UserAccount systemAdmin;
    
    
    public UserAccount getSystemAdmin() {
        return systemAdmin;
    }

    public void setSystemAdmin(UserAccount systemAdmin) {
        this.systemAdmin = systemAdmin;
    }
    public static FoodShelterSystem getInstance(){
        if(business==null){
            business=new FoodShelterSystem();
        }
        return business;
    }
    
    public NetWork createAndAddNetwork(){
        NetWork network=new NetWork();
        networkList.add(network);
        return network;
    }
    
    @Override
    public ArrayList<BasicRole> getSupportedRole() {
        ArrayList<BasicRole> roleList=new ArrayList<>();
        roleList.add(new SysAdmin());
        return roleList;
    }
    
    private FoodShelterSystem(){
        super(null,null);
        networkList=new ArrayList<>();
    }

    public ArrayList<NetWork> getNetworkList() {
        return networkList;
    }

    public void setNetworkList(ArrayList<NetWork> networkList) {
        this.networkList = networkList;
    }
    
    public boolean checkIfUserIsUnique(String userName){
        if(!this.getUserAccountDirectory().checkIfUsernameIsUnique(userName)){
            return false;
        }
        for(NetWork network:networkList){
            
        }
        return true;
    }
    
    public boolean checkNetWorkIsUnique(String name){
        for(NetWork netWork: this.networkList){
            if(netWork.getName().equals(name))
                return false;
        }
        return true;
    }
    
    @Override
    public String toString(){
        return "System";
    }
}
